#!/usr/bin/env python3
"""Specification compliance statement builder.

  extract <spec.pdf|.docx|.doc> -o spec.json   parse clauses into JSON (+ flags typo candidates)
  build   spec.json -o out.xlsx [--fixes fixes.json]   write the formatted Excel statement
"""
import argparse, json, math, os, re, shutil, subprocess, sys, tempfile
from collections import Counter

# ---------------------------------------------------------------- text input
def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, check=True).stdout

def have(tool):
    return shutil.which(tool) is not None

def pdf_text_pages(path):
    """Text layer per page: poppler if installed, else pure-Python fallbacks."""
    if have("pdftotext"):
        pages = run(["pdftotext", "-layout", path, "-"]).split("\f")
        if pages and not pages[-1].strip():
            pages = pages[:-1]
        return pages
    try:
        from pypdf import PdfReader
        return [(p.extract_text(extraction_mode="layout") or "") for p in PdfReader(path).pages]
    except ImportError:
        pass
    try:
        import pdfplumber
        with pdfplumber.open(path) as pdf:
            return [(p.extract_text(x_tolerance=1) or "") for p in pdf.pages]
    except ImportError:
        sys.exit("ERROR: no PDF text extractor. Install poppler-utils, or: pip install pypdf")

def ocr_pages(path):
    if not have("tesseract"):
        sys.exit("SCANNED PDF: no OCR engine (tesseract) available here. Render the pages to images "
                 "and transcribe them visually into spec.json (same structure), or ask the user for a "
                 "text PDF / Word version.")
    tmp = tempfile.mkdtemp()
    try:
        if have("pdftoppm"):
            run(["pdftoppm", "-r", "300", "-png", path, os.path.join(tmp, "p")])
        else:
            import pypdfium2 as pdfium  # pip install pypdfium2
            for i, pg in enumerate(pdfium.PdfDocument(path)):
                pg.render(scale=300 / 72).to_pil().save(os.path.join(tmp, f"p-{i + 1}.png"))
        out = []
        for f in sorted(os.listdir(tmp), key=lambda n: int(re.findall(r"\d+", n)[-1])):
            out.append(run(["tesseract", os.path.join(tmp, f), "-", "--psm", "6"]))
        return out
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

def pdf_pages(path):
    pages = pdf_text_pages(path)
    dense = sum(len(re.sub(r"\s", "", p)) for p in pages) / max(len(pages), 1)
    if dense >= 150:
        return pages, "text-pdf"
    return ocr_pages(path), "ocr"   # scanned: no usable text layer

def get_pages(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".docx", ".doc", ".rtf", ".odt"):
        # render through LibreOffice so Word auto-numbering (A., 1., a.) becomes real text
        if not have("soffice"):
            sys.exit("WORD FILE: LibreOffice (soffice) is not available here, and Word auto-numbering "
                     "cannot be read reliably without it. Ask the user to save the file as PDF "
                     "(File > Save As > PDF) and attach that instead.")
        tmp = tempfile.mkdtemp()
        run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", tmp, path])
        pdf = os.path.join(tmp, os.path.splitext(os.path.basename(path))[0] + ".pdf")
        pages, _ = pdf_pages(pdf)
        return pages, "word"
    return pdf_pages(path)

# ---------------------------------------------------------- header / footer
def norm(line):
    return re.sub(r"\d+", "#", re.sub(r"\s+", " ", line.strip()))

def strip_running_lines(pages, ocr=False):
    import difflib
    n = len(pages)
    counts = Counter()
    for p in pages:
        counts.update({norm(l) for l in p.splitlines() if l.strip()})
    running = {k for k, c in counts.items() if n >= 3 and c >= max(2, 0.5 * n)}
    lines = []
    for p in pages:
        for l in p.splitlines():
            l = l.replace("\u00a0", " ").replace("\u2002", " ").replace("\u2003", " ")
            if ocr:
                l = re.sub(r"^\s*[|_]+\s+", "", l)          # OCR edge noise
                l = re.sub(r"(?<=\s)[|_]+(?=\s)", "", l)     # stray bars between words
                l = l.replace("“", '"').replace("”", '"').replace("’", "'")
                l = re.sub(r"(?<=\d)(-?\s?)KN\b", r"\1kN", l)     # unit case
            s = l.strip()
            if not s:
                continue
            k = norm(l)
            if k in running:
                continue  # repeating page header / footer
            if ocr and len(k) > 15 and any(
                    difflib.SequenceMatcher(None, k, r).ratio() > 0.75 for r in running if len(r) > 15):
                continue  # garbled copy of a running header / footer
            if re.fullmatch(r"[\d ]+(\.\d+)?\s*/\s*\d+", s):
                continue  # page number like "08 71 00 / 4"
            lines.append(re.sub(r"\s+", " ", s))
    return lines

# ------------------------------------------------------------------ parsing
PART = re.compile(r"^PART\s+(\d+)\s*[-–:.]?\s*(.*)$", re.I)
ARTICLE = re.compile(r"^(\d{1,2}\.\d{1,2})\s+(.*)$|^(\d{1,2}\.\d{2})$")
SECTION = re.compile(r"^SECTION\s+(\d{2}\s?\d{2}\s?\d{2}(?:\.\d+)?)\s*(.*)$", re.I)
END = re.compile(r"^END OF SECTION", re.I)
LABEL = re.compile(r"^(?:([A-Za-z])\.|(\d{1,2})\.|(\d{1,2})\)|([a-z])\))(?=\s|$)\s*(.*)$")

def nxt(level, cur):
    if level in (1,):
        return chr(ord(cur) + 1) if cur else "A"
    if level in (3, 5):
        return chr(ord(cur) + 1) if cur else "a"
    return str(int(cur) + 1) if cur else "1"

def fmt(level, v):
    return v + ")" if level in (4, 5) else v + "."

OCR_LOOKALIKE = {"|": "I", "l": "I", "1": "I", "!": "I", "0": "O"}

def classify(line, stack):
    """Return (level, value, rest) if line starts a legal next item, else None."""
    hit = _classify(line, stack)
    if hit:
        return hit
    # OCR glyph confusion ("|." / "1." for "I.") - accepted only if the sequence expects it
    m = re.match(r"^([|l1!0])\.(?=\s)\s*(.*)$", line)
    if m:
        v = OCR_LOOKALIKE[m.group(1)]
        cur = dict(stack).get(1)
        if 1 in dict(stack) and v == nxt(1, cur):
            return 1, v, m.group(2)
    return None

def _classify(line, stack):
    m = LABEL.match(line)
    if not m:
        return None
    up_or_low, num_dot, num_par, low_par, rest = m.groups()
    cands = []
    if up_or_low:
        cands = [(1, up_or_low.upper()), (3, up_or_low.lower())]
        if up_or_low.islower():
            cands.reverse()
    elif num_dot:
        cands = [(2, num_dot)]
    elif num_par:
        cands = [(4, num_par)]
    elif low_par:
        cands = [(5, low_par)]
    deepest = stack[-1][0] if stack else 0
    for lvl, v in cands:
        cur = dict(stack).get(lvl)
        if lvl in dict(stack):
            if v == nxt(lvl, cur):
                return lvl, v, rest
            # tolerate small numbering gaps in the spec itself
            if lvl in (2, 4) and cur and 0 < int(v) - int(cur) <= 2:
                return lvl, v, rest + "\u0000gap"
        elif lvl > deepest and v == nxt(lvl, None):
            return lvl, v, rest
    return None

def append(row, text):
    if not text:
        return
    t = row["text"]
    if not t:
        row["text"] = text
    elif re.search(r"[A-Za-z]-$", t) and re.match(r"[A-Za-z0-9),.;:]", text):
        row["text"] = t + text  # re-join words hyphenated across lines
    else:
        row["text"] = t + " " + text

def parse(lines):
    sec_no, sec_title, rows, warnings = "", [], [], []
    i = 0
    while i < len(lines) and not PART.match(lines[i]):
        m = SECTION.match(lines[i])
        if m:
            sec_no = re.sub(r"\s+", "", m.group(1))
            sec_no = f"{sec_no[:2]} {sec_no[2:4]} {sec_no[4:]}"   # "271000" -> "27 10 00"
            if m.group(2).strip(" -–:"):
                sec_title.append(m.group(2).strip(" -–:"))
            j = i + 1
            while j < len(lines) and not PART.match(lines[j]) and lines[j].isupper():
                sec_title.append(lines[j]); j += 1
        i += 1
    stack, cur = [], None
    for line in lines[i:]:
        if END.match(line):
            break
        m = PART.match(line)
        if m:
            cur = {"type": "part", "label": f"PART {m.group(1)}", "text": m.group(2).upper()}
            rows.append(cur); stack = []; continue
        m = ARTICLE.match(line)
        if m:
            lab, title = (m.group(1), m.group(2)) if m.group(1) else (m.group(3), "")
            two_digit = re.fullmatch(r"\d{1,2}\.\d{2}", lab)
            # "1.01 Title" or "1.1 TITLE" (short form only with an all-caps title)
            if (two_digit and (not title or title[:1].isupper())) or (title and title.isupper()):
                cur = {"type": "article", "label": lab, "text": title}
                rows.append(cur); stack = []; continue
        c = classify(line, stack)
        if c:
            lvl, v, rest = c
            if rest.endswith("\u0000gap"):
                rest = rest[:-4]
                warnings.append(f"numbering gap before {fmt(lvl, v)} in article {last_article(rows)}")
            stack = [s for s in stack if s[0] < lvl] + [(lvl, v)]
            cur = {"type": "item", "level": lvl, "label": fmt(lvl, v), "text": rest}
            rows.append(cur); continue
        if cur is None:
            continue
        if cur["type"] in ("part", "article") and line.isupper() and not cur["text"].endswith("."):
            append(cur, line); continue  # wrapped heading
        if cur["type"] in ("part", "article"):
            cur = {"type": "item", "level": 1, "label": "", "text": line}
            rows.append(cur); continue
        append(cur, line)
    return sec_no, " ".join(sec_title).strip(), rows, warnings

def last_article(rows):
    for r in reversed(rows):
        if r["type"] == "article":
            return r["label"]
    return "?"

# -------------------------------------------------------- typo candidates
SHORT_WORDS = set("""a an as at be by do go he if in is it me my no of on or so to up us we
 m mm cm km kg g kn n kw kv v w a id od ip uv pa hz x ft lb oz ie eg vs st nd rd th o c""".split())

def flag(rows):
    out = []
    pats = [
        # word split by a stray space: "e quipment", "f or", "co ncrete"
        (r"(?<!['’\w])([a-z]{1,2}) ([a-z]{2,})(?![-\w])", lambda m: m.group(1) not in SHORT_WORDS),
        (r"(?<!['’\w])([a-z]{2,}) ([a-z]{1,2})(?![-'’\w])", lambda m: m.group(2) not in SHORT_WORDS),
        # split capitals: "AS TM" (also catches real pairs like "BS EN" - judge, do not join)
        (r"(?<![\w])([A-Z]{1,2}) ([A-Z]{2,5})(?![\w])", lambda m: True),
        # hyphen followed by a stray space: "fire- rated", "50- mm"
        (r"\b\w+- [a-z]\w*", lambda m: True),
        # missing space after comma / colon: "plans,sections", "Finish:Powder-coated"
        (r"[a-z][,:][A-Za-z]", lambda m: True),
    ]
    for idx, r in enumerate(rows):
        if r["type"] != "item":
            continue
        for p, ok in pats:
            for m in re.finditer(p, r["text"]):
                if ok(m):
                    out.append({"row": idx, "fragment": m.group(0)})
    for f in out:
        t = rows[f["row"]]["text"]; k = t.find(f["fragment"])
        f["label"] = rows[f["row"]].get("label", "")
        f["context"] = t[max(0, k - 40): k + len(f["fragment"]) + 40]
    return out

# ------------------------------------------------------------------- Excel
WIDTHS = {"A": 9, "B": 88, "C": 18, "D": 25}   # ~140 units = fits A4 landscape at 100%
B_PX = WIDTHS["B"] * 7 + 5
AVG_CHAR_PX = 5.7                               # Arial 10 (measured ~5.3), kept conservative
LINE_PT = 12.75

def est_height(text, bold=False):
    cpl = max(10, int(B_PX / (AVG_CHAR_PX * (1.08 if bold else 1.0))) - 2)
    lines = sum(max(1, math.ceil(len(p) / cpl)) for p in text.split("\n"))
    return max(15.0, lines * LINE_PT + 3)

def build(spec, out, fixes):
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

    applied = []
    for f in fixes:
        hit = False
        for r in spec["rows"]:
            if f["find"] in r["text"]:
                r["text"] = r["text"].replace(f["find"], f["replace"]); hit = True
                applied.append(f"{r.get('label','')}: '{f['find']}' -> '{f['replace']}'")
        if not hit:
            applied.append(f"NOT FOUND (check spelling of find text): '{f['find']}'")

    wb = Workbook(); ws = wb.active
    ws.title = ("SECTION " + spec["section_number"])[:31] if spec["section_number"] else "Compliance"
    for col, w in WIDTHS.items():
        ws.column_dimensions[col].width = w

    rounded = lambda sz=10: Font(name="Arial Rounded MT Bold", size=sz)
    arial = lambda b=False: Font(name="Arial", size=10, bold=b)
    thin = Side(style="thin"); box = Border(left=thin, right=thin, top=thin, bottom=thin)
    top_c = Alignment(horizontal="center", vertical="top", wrap_text=True)
    just = Alignment(horizontal="justify", vertical="top", wrap_text=True)
    left_top = Alignment(horizontal="left", vertical="top", wrap_text=True)

    ws["A1"] = "PROJECT TITLE:"; ws["A2"] = "SUBMITTAL TITLE:"
    ws["C2"] = "DATE:"; ws["D2"] = "=TODAY()"
    for a in ("A1", "A2", "C2", "D2"):
        ws[a].font = rounded()
    ws["A1"].alignment = ws["A2"].alignment = Alignment(horizontal="left", vertical="center")
    ws["C2"].alignment = Alignment(horizontal="right", vertical="center")
    ws["D2"].alignment = Alignment(horizontal="left", vertical="center")
    ws["D2"].number_format = "[$-409]d-mmm-yyyy;@"

    fill = PatternFill("solid", fgColor="DDEBF7")
    for col, h in zip("ABCD", ["Sl. No", "Specification Requirement", "Compliance Status", "Remarks"]):
        c = ws[f"{col}4"]; c.value = h; c.font = rounded(11); c.fill = fill; c.border = box
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[4].height = 30

    r = 5
    def put(label, text, bold_label, bold_text, label_font=None):
        nonlocal r
        a = ws.cell(r, 1, label or None); b = ws.cell(r, 2, text)
        a.font = label_font or arial(bold_label); a.alignment = top_c; a.number_format = "@"
        b.font = arial(bold_text); b.alignment = just if not bold_text else left_top
        for col in range(1, 5):
            ws.cell(r, col).border = box
        ws.row_dimensions[r].height = est_height(text, bold_text)
        r += 1

    if spec["section_number"]:
        put(None, "SECTION " + spec["section_number"], False, True)
    if spec["section_title"]:
        put(None, spec["section_title"].upper(), False, True)
    for row in spec["rows"]:
        if row["type"] == "part":
            put(row["label"], row["text"], True, True)
        elif row["type"] == "article":
            put(row["label"], row["text"], True, True)
        else:
            txt = (row["label"] + " " + row["text"]).strip()
            put(None, txt, False, False)

    ws.freeze_panes = "A5"
    ws.print_title_rows = "1:4"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = ws.page_margins.right = 0.4
    ws.page_margins.top = ws.page_margins.bottom = 0.6
    ws.print_options.horizontalCentered = True
    ws.oddFooter.center.text = "Page &P of &N"
    ws.oddFooter.center.size = 8
    wb.save(out)
    return applied, r - 1

# --------------------------------------------------------------------- CLI
def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    e = sp.add_parser("extract"); e.add_argument("src"); e.add_argument("-o", required=True)
    b = sp.add_parser("build"); b.add_argument("spec"); b.add_argument("-o", required=True)
    b.add_argument("--fixes")
    a = ap.parse_args()
    if a.cmd == "extract":
        pages, method = get_pages(a.src)
        sec_no, sec_title, rows, warns = parse(strip_running_lines(pages, ocr=(method == "ocr")))
        data = {"source": os.path.basename(a.src), "method": method, "section_number": sec_no,
                "section_title": sec_title, "rows": rows, "warnings": warns, "flags": flag(rows)}
        json.dump(data, open(a.o, "w"), indent=1, ensure_ascii=False)
        cnt = Counter(r["type"] for r in rows)
        print(f"method={method} section={sec_no!r} title={sec_title!r}")
        print(f"parts={cnt['part']} articles={cnt['article']} items={cnt['item']} "
              f"warnings={len(warns)} typo-candidates={len(data['flags'])}")
        for w in warns: print("WARN", w)
        for f in data["flags"]: print("FLAG", f["label"], "|", f["fragment"], "|", f["context"])
    else:
        spec = json.load(open(a.spec))
        fixes = json.load(open(a.fixes)) if a.fixes else []
        applied, last = build(spec, a.o, fixes)
        print(f"wrote {a.o} rows 1-{last}; fixes applied={len(applied)}")
        for x in applied: print("FIX", x)

if __name__ == "__main__":
    main()
